import java.util.ArrayList;
import java.util.List;

public class Ciudades {

	
	 private String id;
	 private String nombreCiudad;
	 List<Ciudades> listac = new ArrayList<Ciudades>();

	 
	 
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombreCiudad() {
		return nombreCiudad;
	}
	public void setNombreCiudad(String nombreCiudad) {
		this.nombreCiudad = nombreCiudad;
	}
	 
	
	public String toString() {
	      return nombreCiudad;
	   }
	 
	
	
	
	 public List<Ciudades> getListac() {
		return listac;
	}
	public void setListac(List<Ciudades> listac) {
		this.listac = listac;
	}
	
}
