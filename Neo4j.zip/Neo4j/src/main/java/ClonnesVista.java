import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.border.TitledBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Font;

public class ClonnesVista extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClonnesVista frame = new ClonnesVista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClonnesVista() {
		setClosable(true);
		setBounds(100, 100, 532, 203);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(null, "Datos", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		getContentPane().add(panel, BorderLayout.CENTER);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal greeter = new Principal();
		 		String aux = (String) comboBox.getSelectedItem();
		 		aux= aux.substring(0,aux.indexOf('-'));
		    	greeter.analisisNodos(aux); // dretonra listado
				
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "GUP-Guayaquil Parques", "GUI-Guayaquil Iglesias", "GUH-Guayaquil Hospitales", "GUB-Guayaquil Bomberos", "GUE-Guayaquil Escuelas", "GUT-Guayaquil L. Turisticos"}));
		comboBox.setBounds(205, 65, 181, 22);
		panel.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Lugares Guayaquil Ec");
		lblNewLabel_1.setBounds(22, 68, 134, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Los nodos  con un alto puntaje de cercan\u00EDa tienen las distancias m\u00E1s cortas");
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblNewLabel.setBounds(12, 13, 492, 39);
		panel.add(lblNewLabel);

	}
}
