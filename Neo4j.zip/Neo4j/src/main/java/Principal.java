import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Record;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.neo4j.driver.Transaction;
import org.neo4j.driver.TransactionWork;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;

import static org.neo4j.driver.Values.parameters;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Principal implements AutoCloseable
{
    private final Driver driver;
    String rows = "";

    public Principal(  )
    {
    	String uri = "bolt://localhost:7687";
        String user= "neo4j";
        String password = "root";
        driver = GraphDatabase.driver( uri, AuthTokens.basic( user, password ) );
    }

    @Override
    public void close() throws Exception
    {
        driver.close();
    }

    public void analisisNodos( final String ciudad )
    {
        try ( Session session = driver.session() )
        {
            String greeting = session.writeTransaction( new TransactionWork<String>()
            {
                @Override
                public String execute( Transaction tx )
                {
//                    Result result = tx.run( "CREATE (a:Greeting) " +
//                                                     "SET a.message = $message " +
//                                                     "RETURN a.message + ', from node ' + id(a)",
//                            parameters( "message", message ) );
                    //return null;// result.single().get( 0 ).asString();
                	
                	 Result result = tx.run("CALL gds.alpha.closeness.stream({\r\n" + 
                	 		"  nodeProjection: '" + ciudad + "',\r\n" + 
                	 		"  relationshipProjection: 'LINK'\r\n" + 
                	 		"})\r\n" + 
                	 		"YIELD nodeId, centrality\r\n" + 
                	 		"RETURN gds.util.asNode(nodeId).name AS user, centrality\r\n" + 
                	 		"ORDER BY centrality DESC");
                	 
                	 Result result2 = tx.run("start n = node(*) where n.Name =~ '.*C.*' return n.Name, n;");
					
					 for (Record linea : result.list()) {
						 	System.out.println("----------------------------------------------------------------------------------\n");
							System.out.println("Lugar es: "+linea.get(0).toString()+"  ------  Distancia es:"+linea.get(1).asDouble());
							
						}
					 return null;//result.toString();// result.single().get( 0 ).asString();
                }
            } );
            
            //System.out.println( greeting );
        }
    }
    
    
    public void analisisNodosWeakly( )
    {
        try ( Session session = driver.session() )
        {
            String greeting = session.writeTransaction( new TransactionWork<String>()
            {
                @Override
                public String execute( Transaction tx )
                {
//                    Result result = tx.run( "CREATE (a:Greeting) " +
//                                                     "SET a.message = $message " +
//                                                     "RETURN a.message + ', from node ' + id(a)",
//                            parameters( "message", message ) );
                    //return null;// result.single().get( 0 ).asString();
                	
                	 Result result = tx.run("CALL gds.wcc.stream('myGraph')\r\n" + 
                	 		"YIELD nodeId, componentId\r\n" + 
                	 		"RETURN gds.util.asNode(nodeId).name AS name, componentId ORDER BY componentId, name limit 10");
                	 
                	 //Result result2 = tx.run("start n = node(*) where n.Name =~ '.*C.*' return n.Name, n;");
					
					 for (Record linea : result.list()) {
							System.out.println("Lugar >> "+linea.get(0).toString());
							
						}
					 return null;//result.toString();// result.single().get( 0 ).asString();
                }
            } );
           // System.out.println( greeting );
        }
    }
    
    public void analisisNodosANN( )
    {
        try ( Session session = driver.session() )
        {
            String greeting = session.writeTransaction( new TransactionWork<String>()
            {
                @Override
                public String execute( Transaction tx )
                {
//                    Result result = tx.run( "CREATE (a:Greeting) " +
//                                                     "SET a.message = $message " +
//                                                     "RETURN a.message + ', from node ' + id(a)",
//                            parameters( "message", message ) );
                    //return null;// result.single().get( 0 ).asString();
                	
                	 Result result = tx.run("MATCH (p:Person)-[:PAR]->(cuisine)\r\n" + 
                	 		" WITH {item:id(p), categories: collect(id(cuisine))} AS userData\r\n" + 
                	 		" WITH collect(userData) AS data\r\n" + 
                	 		" CALL gds.alpha.ml.ann.stream({\r\n" + 
                	 		"   nodeProjection: '*',\r\n" + 
                	 		"   relationshipProjection: '*',\r\n" + 
                	 		"   data: data,\r\n" + 
                	 		"   algorithm: 'jaccard',\r\n" + 
                	 		"   similarityCutoff: 0.1,\r\n" + 
                	 		"   concurrency: 1\r\n" + 
                	 		" })\r\n" + 
                	 		" YIELD item1, item2, similarity\r\n" + 
                	 		" return gds.util.asNode(item1).name AS from, gds.util.asNode(item2).name AS to, similarity\r\n" + 
                	 		" ORDER BY from");
                	 
                	 //Result result2 = tx.run("start n = node(*) where n.Name =~ '.*C.*' return n.Name, n;");
					
					 for (Record linea : result.list()) {
							System.out.println("La Persona >> "+linea.get(0).toString() + " con >>"+linea.get(1).toString() +" Tienen una similitud de " + linea.get(2).asDouble());
							
						}
					 return null;//result.toString();// result.single().get( 0 ).asString();
                }
            } );
           // System.out.println( greeting );
        }
    }
    
    public void analisisNodosMinimum(final String lugar )
    {
        try ( Session session = driver.session() )
        {
            String greeting = session.writeTransaction( new TransactionWork<String>()
            {
                @Override
                public String execute( Transaction tx )
                {
////                    CALL gds.alpha.closeness.stream({\r\n" + 
//        	 		"  nodeProjection: '" + ciudad + "',\r\n" + 
//        	 		"  relationshipProjection: 'LINK'\r\n" + 
//        	 		"})\r\n" + 
//        	 		"YIELD nodeId, centrality\r\n" + 
//        	 		"RETURN gds.util.asNode(nodeId).name AS user, centrality\r\n" + 
//        	 		"ORDER BY centrality DESC
                	
                	 Result result = tx.run("MATCH path = (n:Place {id:'"+lugar+"'})-[:LINK*]-()\r\n" + 
                	 		"WITH relationships(path) AS rels\r\n" + 
                	 		"UNWIND rels AS rel\r\n" + 
                	 		"WITH DISTINCT rel AS rel\r\n" + 
                	 		"RETURN startNode(rel).id AS source, endNode(rel).id AS destination, rel.cost AS cost ORDER BY cost ASC");
                	 
                	 //Result result2 = tx.run("start n = node(*) where n.Name =~ '.*C.*' return n.Name, n;");
					
					 for (Record linea : result.list()) {
						 	System.out.println("----------------------------------------------------------------------------------------------------");
							System.out.println("Inicio "+linea.get(0).toString() + " \tDestino >>"+linea.get(1).toString() +" \tCosto " + linea.get(2).asDouble());
							
						}
					 return null;//result.toString();// result.single().get( 0 ).asString();
                }
            } );
            //System.out.println( greeting );
        }
    }
    
    
    public void analisisNodosVTotal(final String lugar,final String lugar2)
    {
        try ( Session session = driver.session() )
        {
            String greeting = session.writeTransaction( new TransactionWork<String>()
            {
                @Override
                public String execute( Transaction tx )
                {
////                    CALL gds.alpha.closeness.stream({\r\n" + 
//        	 		"  nodeProjection: '" + ciudad + "',\r\n" + 
//        	 		"  relationshipProjection: 'LINK'\r\n" + 
//        	 		"})\r\n" + 
//        	 		"YIELD nodeId, centrality\r\n" + 
//        	 		"RETURN gds.util.asNode(nodeId).name AS user, centrality\r\n" + 
//        	 		"ORDER BY centrality DESC
                	
                	 Result result = tx.run("MATCH (p1:Person {name: '"+lugar+"' })\r\n" + 
                	 		"MATCH (p2:Person {name: '"+ lugar2+"'})\r\n" + 
                	 		"RETURN gds.alpha.linkprediction.totalNeighbors(p1, p2) AS score");
                	 
                	 //Result result2 = tx.run("start n = node(*) where n.Name =~ '.*C.*' return n.Name, n;");
					
					 for (Record linea : result.list()) {
						 	System.out.println("------------------------------------------------------------------------");
						 	System.out.println(" '0' Indica que los lugares no estan cerca \t ' Si el numero es mayor es cercano' \n");
							System.out.println((char)27 + "[30;36mCercania de: "+linea.get(0).asDouble());
							
						}
					 return null;//result.toString();// result.single().get( 0 ).asString();
                }
            } );
           // System.out.println( greeting );
        }
    }
    
    
    Transaction tx;
    Result result =null;
    GraphDatabaseService graphDb;
    Node firstNode;
    Node secondNode;
    Relationship relationship;
    
    public void test() {
    	
    	try ( Session session = driver.session())
        {
    		tx = session.beginTransaction();
    		// result =  tx.run("CREATE (CQ:CIUDAD {title:'CIUDAD', tagline:'CIUDAD '}) RETURN CQ.message + ', from node ' + id(CQ)", parameters("name","CIUDAD"));
            //myNode.setProperty( "name", "BIGPABLO" );
            tx.commit();//.commit();
            System.out.println( "Se creo >>" );
        }
    	
    	
        try (  Session session = driver.session())
          {
        	 tx = session.beginTransaction();
    		//Transaction tx = db.beginTx();
             result = tx.run( "MATCH (n {name: 'CIUDAD'}) RETURN n, n.name" );
              while ( result.hasNext() )
              {
                  Map<String,Object> row = (Map<String, Object>) result.next();
                  for ( Entry<String,Object> column : row.entrySet() )
                  {
                      rows += column.getKey() + ": " + column.getValue() + "; ";
                  }
                  rows += "\n";
              }
            //  System.out.println("los vaoes son >>> "+ rows);
          }
        
    }
   
}
