import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class TotalVista extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	String aux = "";
	String aux1 = "";
	String aux2 = "";
	String aux3 = "";
	String aux4 = "";
	String aux5 = "";
	String aux6 = "";
	
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TotalVista frame = new TotalVista();
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TotalVista() {
		setClosable(true);
		setBounds(100, 100, 884, 428);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Parques");
		lblNewLabel.setBounds(406, 45, 56, 16);
		getContentPane().add(lblNewLabel);
		
		JComboBox comboBoxMinimum = new JComboBox();
		comboBoxMinimum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aux = (String) comboBoxMinimum.getSelectedItem();
				
				
				
			}
		});
		comboBoxMinimum.setModel(new DefaultComboBoxModel(new String[] {"", "Parque Provincial de la Familia", "Parque Luis A. Martinez", "Parque de las Flores", "Parque Los Quindes", "Parque Yuragasha"}));
		comboBoxMinimum.setBounds(336, 74, 194, 30);
		getContentPane().add(comboBoxMinimum);
		
		JLabel lblIglesias = new JLabel("Iglesias");
		lblIglesias.setBounds(101, 127, 56, 16);
		getContentPane().add(lblIglesias);
		
		JComboBox comboBoxMinimum_1 = new JComboBox();
		comboBoxMinimum_1.setModel(new DefaultComboBoxModel(new String[] {"", "Iglesia del Perpetuo Socorro", "La Iglesia de Jesucristo SUD, Capilla Ambato", "Iglesia De Dios La ROCA", "Iglesia Alianza Ficoa", "Iglesia Cat\u00F3lica de La Medalla Milagrosa"}));
		comboBoxMinimum_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aux1 = (String) comboBoxMinimum_1.getSelectedItem();
				
			}
		});
		comboBoxMinimum_1.setBounds(44, 156, 194, 30);
		getContentPane().add(comboBoxMinimum_1);
		
		JLabel lblHospitales = new JLabel("Hospitales");
		lblHospitales.setBounds(313, 130, 70, 16);
		getContentPane().add(lblHospitales);
		
		JComboBox comboBoxMinimum_1_1 = new JComboBox();
		comboBoxMinimum_1_1.setModel(new DefaultComboBoxModel(new String[] {"", "Clinica San Bartolome", "Hospital B\u00E1sico Central Ambato", "Hospital Privado Tungurahua. Esmedicas S.A", "Hospital Del IESS Ambato", "Hospital Guz Medical"}));
		comboBoxMinimum_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Principal p = new Principal();
				aux2 = (String) comboBoxMinimum_1_1.getSelectedItem();
				
			}
		});
		comboBoxMinimum_1_1.setBounds(250, 156, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1);
		
		JLabel lblBomberos = new JLabel("Bomberos");
		lblBomberos.setBounds(506, 127, 76, 16);
		getContentPane().add(lblBomberos);
		
		JComboBox comboBoxMinimum_1_1_1 = new JComboBox();
		comboBoxMinimum_1_1_1.setModel(new DefaultComboBoxModel(new String[] {"", "Bomberos la pradera", "Cuerpo De Bomberos Compa\u00F1\u00EDa X-2 Huachi", "Estaci\u00F3n de bomberos", "EMBA EP Cia X-3", ""}));
		comboBoxMinimum_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Principal p = new Principal();
				aux3 = (String) comboBoxMinimum_1_1_1.getSelectedItem();
				
			}
		});
		comboBoxMinimum_1_1_1.setBounds(456, 156, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_1);
		
		JLabel lblEscuelas = new JLabel("Policia");
		lblEscuelas.setBounds(717, 127, 56, 16);
		getContentPane().add(lblEscuelas);
		
		JComboBox comboBoxMinimum_1_1_2 = new JComboBox();
		comboBoxMinimum_1_1_2.setModel(new DefaultComboBoxModel(new String[] {"", "UPC Las Acacias", "UVC Ambato", "Corte Provincial", "Cooperativa Policia Nacional", "DINAPEN"}));
		comboBoxMinimum_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Principal p = new Principal();
				aux4 = (String) comboBoxMinimum_1_1_2.getSelectedItem();
				
			}
		});
		comboBoxMinimum_1_1_2.setBounds(660, 156, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_2);
		
		JLabel lblEscuelas_1 = new JLabel("Escuelas");
		lblEscuelas_1.setBounds(259, 232, 56, 16);
		getContentPane().add(lblEscuelas_1);
		
		JComboBox comboBoxMinimum_1_1_2_1 = new JComboBox();
		comboBoxMinimum_1_1_2_1.setModel(new DefaultComboBoxModel(new String[] {"", "Unidad Educativa G\u00E9nesis", "Escuela Pedro Ferm\u00EDn Cevallos", "Unidad Educativa Le\u00F3n Becerra", "Escuela Venezuela", "Escuela de Educaci\u00F3n B\u00E1sica Carmen Barona"}));
		comboBoxMinimum_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Principal p = new Principal();
				aux5 = (String) comboBoxMinimum_1_1_2_1.getSelectedItem();
				
				
			}
		});
		comboBoxMinimum_1_1_2_1.setBounds(194, 258, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_2_1);
		
		JLabel lblEscuelas_1_1 = new JLabel("Lugares Turisticos");
		lblEscuelas_1_1.setBounds(556, 232, 117, 16);
		getContentPane().add(lblEscuelas_1_1);
		
		JComboBox comboBoxMinimum_1_1_2_1_1 = new JComboBox();
		comboBoxMinimum_1_1_2_1_1.setModel(new DefaultComboBoxModel(new String[] {"", "Mausoleo de Montalvo", "Bas\u00EDlica Catedral de Nuestra Se\u00F1ora de la Elevaci\u00F3n", "Museo del Colegio Nacional Bolivar", "Parque Montalvo", "Museo Pict\u00F3rico Edmundo Martinez"}));
		comboBoxMinimum_1_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Principal p = new Principal();
				aux6 = (String) comboBoxMinimum_1_1_2_1_1.getSelectedItem();
				
				
				
			}
		});
		comboBoxMinimum_1_1_2_1_1.setBounds(506, 261, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_2_1_1);
		
		JLabel lblLoja = new JLabel("AMBATO");
		lblLoja.setBounds(406, 13, 56, 16);
		getContentPane().add(lblLoja);
		
		JButton btnNewButton = new JButton("ok");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				op();
			}
		});
		btnNewButton.setBounds(402, 332, 97, 25);
		getContentPane().add(btnNewButton);

	}

	void op() {
		Principal p = new Principal();
		System.out.println("--------------------------------------------------------------------------------\n");
		System.out.println(" ----> "+aux +" -- "+aux1+" -- "+aux2+" -- "+aux3+" -- "+aux4+" -- "+aux5+" -- "+aux6);
		//System.out.println("----->"+aux +"---"+aux1);
		p.analisisNodosVTotal(aux, aux1);
		//System.out.println("----->"+aux +"---"+aux2);
		p.analisisNodosVTotal(aux, aux2);
		//System.out.println("----->"+aux +"---"+aux3);
		p.analisisNodosVTotal(aux, aux3);
		//System.out.println("----->"+aux +"---"+aux4);
		p.analisisNodosVTotal(aux, aux4);
		//System.out.println("----->"+aux +"---"+aux5);
		p.analisisNodosVTotal(aux, aux5);
		//System.out.println("----->"+aux +"---"+aux6);
		p.analisisNodosVTotal(aux, aux6);
		
	
		
	}
}
