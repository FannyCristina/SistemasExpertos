import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;

public class MinumumVista extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MinumumVista frame = new MinumumVista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MinumumVista() {
		setClosable(true);
		setBounds(100, 100, 970, 385);
		getContentPane().setLayout(null);
		
		JComboBox comboBoxMinimum = new JComboBox();
		comboBoxMinimum.setModel(new DefaultComboBoxModel(new String[] {"", "Parque Umi\u00F1a", "Parque Santa Marianita", "Parque De La Armada", "Parque Santa M\u00F3nica", "Parque Santa Fe"}));
		comboBoxMinimum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
				
			}
		});
		comboBoxMinimum.setBounds(33, 61, 194, 30);
		getContentPane().add(comboBoxMinimum);
		
		JLabel lblNewLabel = new JLabel("Parques");
		lblNewLabel.setBounds(90, 32, 56, 16);
		getContentPane().add(lblNewLabel);
		
		JComboBox comboBoxMinimum_1 = new JComboBox();
		comboBoxMinimum_1.setModel(new DefaultComboBoxModel(new String[] {"", "Iglesia Perpetuo Socorro", "Iglesia Bautista Misionera De Manta", "Iglesia Catolica La Dolorosa", "Capilla del Sant\u00EDsimo Sacramento", "Iglesia Cristiana Verbo"}));
		comboBoxMinimum_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum_1.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
			}
		});
		comboBoxMinimum_1.setBounds(33, 156, 194, 30);
		getContentPane().add(comboBoxMinimum_1);
		
		JLabel lblIglesias = new JLabel("Iglesias");
		lblIglesias.setBounds(90, 127, 56, 16);
		getContentPane().add(lblIglesias);
		
		JComboBox comboBoxMinimum_1_1 = new JComboBox();
		comboBoxMinimum_1_1.setModel(new DefaultComboBoxModel(new String[] {"", "Centro De Salud Tipo C DE Manta", "Cl\u00EDnica Gavilanes", "Clinica Americana", "Manta Hospital Center", "Hospital Rodriguez"}));
		comboBoxMinimum_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum_1_1.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
			}
		});
		comboBoxMinimum_1_1.setBounds(33, 260, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1);
		
		JLabel lblHospitales = new JLabel("Hospitales");
		lblHospitales.setBounds(90, 231, 70, 16);
		getContentPane().add(lblHospitales);
		
		JLabel lblManta = new JLabel("Manta");
		lblManta.setBounds(481, 0, 56, 16);
		getContentPane().add(lblManta);
		
		JLabel lblBomberos = new JLabel("Bomberos");
		lblBomberos.setBounds(474, 32, 76, 16);
		getContentPane().add(lblBomberos);
		
		JComboBox comboBoxMinimum_1_1_1 = new JComboBox();
		comboBoxMinimum_1_1_1.setModel(new DefaultComboBoxModel(new String[] {"", "Cuerpo De Bomberos Manta Estaci\u00F3n-6", "Benem\u00E9rito Cuerpo De Bomberos De Manta", "Cuerpo DE Bomberos", "Cuerpo De Bomberos De Manta", "Estaci\u00F3n De Bomberos Los Esteros"}));
		comboBoxMinimum_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum_1_1_1.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
			}
		});
		comboBoxMinimum_1_1_1.setBounds(424, 61, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_1);
		
		JLabel lblEscuelas = new JLabel("Policia");
		lblEscuelas.setBounds(481, 127, 56, 16);
		getContentPane().add(lblEscuelas);
		
		JComboBox comboBoxMinimum_1_1_2 = new JComboBox();
		comboBoxMinimum_1_1_2.setModel(new DefaultComboBoxModel(new String[] {"", "UPC Murcielago 1", "UPC TARQUI 1", "Cuartel De Polic\u00EDa Tarqui", "UPC UNIVERSIDAD 2", "UPC UNIVERSIDAD 1"}));
		comboBoxMinimum_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum_1_1_2.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
				
			}
		});
		comboBoxMinimum_1_1_2.setBounds(424, 156, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_2);
		
		JLabel lblEscuelas_1 = new JLabel("Escuelas");
		lblEscuelas_1.setBounds(481, 231, 56, 16);
		getContentPane().add(lblEscuelas_1);
		
		JComboBox comboBoxMinimum_1_1_2_1 = new JComboBox();
		comboBoxMinimum_1_1_2_1.setModel(new DefaultComboBoxModel(new String[] {"", "Escuela Fiscal Mixta Ciudad De Manta", "Unidad Educativa Fiscal Manta", "Josefa Mendoza De Mora", "Escuela Rep\u00FAblica Del Ecuador", "Unidad Educativa julio Pierregrosse"}));
		comboBoxMinimum_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum_1_1_2_1.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
				
			}
		});
		comboBoxMinimum_1_1_2_1.setBounds(424, 260, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_2_1);
		
		JComboBox comboBoxMinimum_1_1_2_1_1 = new JComboBox();
		comboBoxMinimum_1_1_2_1_1.setModel(new DefaultComboBoxModel(new String[] {"", "Museo Centro Cultural Manta", "Malec\u00F3n Esc\u00E9nico Murci\u00E9lago", "Playa Murci\u00E9lago", "Museo Canceb\u00ED", "Parque Centenario"}));
		comboBoxMinimum_1_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Principal p = new Principal();
				String aux = (String) comboBoxMinimum_1_1_2_1_1.getSelectedItem();
				p.analisisNodosMinimum(aux);
				
				
			}
		});
		comboBoxMinimum_1_1_2_1_1.setBounds(725, 61, 194, 30);
		getContentPane().add(comboBoxMinimum_1_1_2_1_1);
		
		JLabel lblEscuelas_1_1 = new JLabel("Lugares Turisticos");
		lblEscuelas_1_1.setBounds(758, 32, 117, 16);
		getContentPane().add(lblEscuelas_1_1);

	}
}
