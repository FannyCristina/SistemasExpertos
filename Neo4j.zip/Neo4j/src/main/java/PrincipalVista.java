import java.awt.EventQueue;
import java.awt.TextArea;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import org.apache.commons.compress.compressors.lz4.XXHash32;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;

public class PrincipalVista {

	private JFrame frame;
	public static JDesktopPane desktopPaneEscritorio;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrincipalVista window = new PrincipalVista();
					//window.frame.setExtendedState();
					window.frame.setVisible(true);
					
					
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrincipalVista() {
		initialize();
		cargavalores();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	JTextArea textArea = new JTextArea();
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1114, 580);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Asistente de Turismo");
		lblNewLabel.setBounds(485, 1, 381, 41);
		frame.getContentPane().add(lblNewLabel);
		
		JDesktopPane desktopPaneEscritorio = new JDesktopPane();
		desktopPaneEscritorio.setBounds(12, 55, 1083, 495);
		frame.getContentPane().add(desktopPaneEscritorio);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("menu");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("1 Closeness Centrality ");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ClonnesVista cv = new ClonnesVista();
				desktopPaneEscritorio.add(cv);
				cv.setVisible(true);
				
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("2 Weakly Connected Components");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WeaklyVista wv = new WeaklyVista();
				desktopPaneEscritorio.add(wv);
				wv.setVisible(true);
				
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("3 Approximate Nearest Neighbors ");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnnVista av = new AnnVista();
				desktopPaneEscritorio.add(av);
				av.setVisible(true);
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("4 Minimum Weight Spanning Tree ");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MinumumVista mv = new MinumumVista();
				desktopPaneEscritorio.add(mv);
				mv.setVisible(true);				
				
			}
		});
		mnNewMenu.add(mntmNewMenuItem_3);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("5 Total Neighbors ");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TotalVista tv = new TotalVista();
				desktopPaneEscritorio.add(tv);
				tv.setVisible(true);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_4);
	}
	void cargavalores() {
		Ciudades c = new Ciudades();
//		c.getListac().add(c);
//		
//		c.setId("CQ");
//		c.setNombreCiudad("Quito");
//		c.getListac().add(c);
//		
		
		
		
	}
}
