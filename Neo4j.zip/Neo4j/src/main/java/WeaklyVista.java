import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class WeaklyVista extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WeaklyVista frame = new WeaklyVista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WeaklyVista() {
		setClosable(true);
		setBounds(100, 100, 446, 264);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Principal greeter = new Principal();
				greeter.analisisNodosWeakly();
				
			}
		});
		getContentPane().add(btnNewButton, BorderLayout.WEST);
		
		JLabel lblNewLabel = new JLabel("Agrupa de acuerdo al peso");
		lblNewLabel.setFont(new Font("Yu Gothic Medium", Font.PLAIN, 24));
		getContentPane().add(lblNewLabel, BorderLayout.CENTER);

	}

}
